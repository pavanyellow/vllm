# τ³-bench Evaluation Results

**Benchmark:** τ³-bench (Sierra AI)  
**Date:** 2026-06-03  
**Setup:** 1 trial, seed 300, text mode (half-duplex), max 200 steps  
**User Sim:** gpt-5.2 (temperature 1.0, top_p 0.95, reasoning_effort low) — matches leaderboard config

## Retail (114 tasks)

| Model | Pass Rate | Reasoning | User Sim | Trials | DB Match | Read Actions | Write Actions | Tool Accuracy | Comm Pass | Transfer Rate |
|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|
| **Qwen3.6-35B-A3B (ours)** | **76.3%** | **none** | **gpt-5.2** | **1** | **77.2%** | **88.5%** | **80.5%** | **85.9%** | **91.4%** | **7.0%** |
| GPT-4.1 | 63.2% | none | gpt-5.2 | 1 | 69.3% | 83.5% | 77.8% | 96.2% | 86.9% | 22.8% |

## Airline (50 tasks)

| Model | Pass Rate | Reasoning | User Sim | Trials | DB Match | Read Actions | Write Actions | Tool Accuracy | Comm Pass | Transfer Rate |
|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|
| **Qwen3.6-35B-A3B (ours)** | **63.3%** | **none** | **gpt-5.2** | **1** | **65.3%** | **97.8%** | **60.4%** | **84.9%** | **83.3%** | **32.7%** |
| GPT-4.1 | 50.0% | none | gpt-5.2 | 1 | 50.0% | 88.0% | 58.0% | 96.8% | 70.0% | 26.0% |

## Telecom (114 tasks)

| Model | Pass Rate | Reasoning | User Sim | Trials | DB Match | Read Actions | Write Actions | Tool Accuracy | Comm Pass | Transfer Rate | Median Input Tok |
|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| **Qwen3.6-35B-A3B (ours)** | **97.4%** | **none** | **gpt-5.2** | **1** | **26.3%** | **—** | **99.4%** | **99.4%** | **—** | **16.7%** | **2,310** |
| GPT-4.1 | 65.8% | none | gpt-5.2 | 1 | 17.5% | 90.0% | 91.6% | 99.9% | — | 40.4% | — |

## Banking Knowledge (97 tasks)

| Model | Pass Rate | Reasoning | User Sim | Trials | DB Match | Read Actions | Write Actions | Tool Accuracy | Comm Pass | Transfer Rate | Median Input Tok |
|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| **Qwen3.6-35B-A3B (ours)** | **6.2%** | **none** | **gpt-5.2** | **1** | **7.2%** | **83.3%** | **32.7%** | **33.2%** | **—** | **13.4%** | **22,598** |
| GPT-4.1 | 19.1%* | none | gpt-5.2 | 1 | — | — | — | — | — | — | — |

*GPT-4.1 banking in progress (49/97)*
