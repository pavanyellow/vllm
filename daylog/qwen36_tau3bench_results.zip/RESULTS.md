# τ³-bench Evaluation Results

**Benchmark:** τ³-bench (Sierra AI)  
**Date:** 2026-06-02  
**Setup:** 1 trial, temperature 0.2, text mode (half-duplex), max 200 steps  
**Agent:** Qwen3.6-35B-A3B (thinking off) · **User Sim:** gpt-5.2 (reasoning_effort: low) · seed 300

## Retail (114 tasks)

| Model | Pass Rate | Reasoning | User Sim | Trials | DB Match | Read Actions | Write Actions | Tool Accuracy | Comm Pass | Transfer Rate | Median Input Tok |
|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Qwen3.6-35B-A3B | 76.3% | none | gpt-5.2 | 1 | 77.2% | 88.5% | 80.5% | 85.9% | 91.4% | 7.0% | 2,584 |

## Airline (50 tasks)

| Model | Pass Rate | Reasoning | User Sim | Trials | DB Match | Read Actions | Write Actions | Tool Accuracy | Comm Pass | Transfer Rate | Median Input Tok |
|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Qwen3.6-35B-A3B | 63.3% | none | gpt-5.2 | 1 | 65.3% | 97.8% | 60.4% | 84.9% | 83.3% | 32.7% | 3,149 |

_Airline: 49/50 scored; 1 task dropped after a step-loop hang (would score 0; full-50 Pass Rate = 62.0%)._

## Telecom (114 tasks)

| Model | Pass Rate | Reasoning | User Sim | Trials | DB Match | Read Actions | Write Actions | Tool Accuracy | Comm Pass | Transfer Rate | Median Input Tok |
|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Qwen3.6-35B-A3B | 97.4% | none | gpt-5.2 | 1 | 26.3% | — | 99.4% | 99.4% | — | 16.7% | 2,310 |

## Banking (97 tasks)

| Model | Pass Rate | Reasoning | User Sim | Trials | DB Match | Read Actions | Write Actions | Tool Accuracy | Comm Pass | Transfer Rate | Median Input Tok |
|---|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Qwen3.6-35B-A3B | 6.2% | none | gpt-5.2 | 1 | 7.2% | 83.3% | 32.7% | 33.2% | — | 13.4% | 22,598 |

