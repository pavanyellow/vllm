# aiwf-eval (aiwf_medium_context) — Qwen3.6-35B-A3B Results

**Benchmark:** kwindla/aiewf-eval, `aiwf_medium_context` (30-turn conversation, ~15K-token avg prompt)
**Agent:** Qwen3.6-35B-A3B (FP8), **thinking off**, temperature 0.2
**Judge:** claude-opus-4-5 (repo default), 3 dims: tool_use_correct, instruction_following, kb_grounding
**Sample:** 10 runs x 30 turns = 300 turns per config, strict turn pass (all 3 dims)

| Config | Pass Rate | Tool Use | Instruction | KB Grounding |
|---|---:|---:|---:|---:|
| baseline (original prompt) | 91.7% (275/300) | 93.0% | 91.7% | 100% (300/300) |
| + 5-line tool-orchestration guard | 94.0% (282/300) | 96.0% | 94.0% | 100% (300/300) |

Reference: gpt-4.1 on the repo leaderboard = 96.3% (same claude-opus-4-5 judge).

## Folders
- `baseline_91.7pct/run_01..10/` — original prompt
- `guard_94.0pct/run_01..10/` — +5-line guard (system.py: rules 8a/9a/9b + reworded 7/9)
- each run: `transcript.jsonl` (per-turn agent output + tool calls), `claude_judged.jsonl` (per-turn judgments + reasoning), `claude_summary.json`
- `qwen3.6-35B-A3B_aiwf-medium_failure-analysis.md` — failure taxonomy
