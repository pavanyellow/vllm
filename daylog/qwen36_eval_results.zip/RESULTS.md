# Evaluation Results — Qwen3.6-35B-A3B

Two benchmark suites. Qwen3.6-35B-A3B is run with **thinking off**, temperature 0.2.

---

## 1. τ³-bench (Sierra AI) — tool-agent tasks

**Setup:** 1 trial, seed 300, text mode (half-duplex), max 200 steps.
**User simulator:** gpt-5.2 (reasoning_effort: low) — leaderboard standard.
Comparison baseline: GPT-4.1 (gpt-4.1-2025-04-14, temperature 0.0), same user simulator.

| Domain | Tasks | Qwen3.6-35B-A3B (thinking off) | GPT-4.1 |
|---|---:|---:|---:|
| Retail   | 114 | **76.3%** | 68.4% |
| Airline  |  50 | **63.3%** | 50.0% |
| Telecom  | 114 | **97.4%** | 65.8% |
| Banking  |  97 | 6.2%      | 13.4% |
| **Overall** | | **60.8%** | 49.4% |

Overall = unweighted mean of the four domains' pass rate.
Raw per-task results in `tau-bench/qwen/` and `tau-bench/gpt-4.1/`.

---

## 2. aiewf-eval — `aiwf_medium_context` (multi-turn voice-agent)

**Setup:** 10 runs × 30 turns, temperature 0.2, judged by claude-opus-4-5 across 3 dimensions
(tool-use correctness, instruction following, KB grounding).

| Configuration | Score |
|---|---:|
| Baseline | 91.7% |
| + 5-line prompt guard | **94.0%** |

KB grounding was 100% in every configuration — residual failures are tool-orchestration only.
Raw transcripts in `aiwf-eval/baseline_91.7pct/` and `aiwf-eval/guard_94.0pct/`.
